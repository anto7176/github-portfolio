<?php

namespace Controllers;

class MainController {

    public function index($params = []) {
    echo '<h1>Bienvenue sur la page d\'index</h1>';
    }

    public function search($params = []) {
    // Afficher la page de recherche
    echo '<h1>Recherche</h1>';
    }
    }
